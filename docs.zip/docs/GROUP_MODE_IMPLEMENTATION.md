# تنفيذ نظام إدارة اللاعبين في الوضع الجماعي

## نظرة عامة

تم تنفيذ نظام شامل لإدارة اللاعبين في الوضع الجماعي، يسمح للمضيف بإضافة، تعديل، وحذف اللاعبين قبل بدء اللعبة، بالإضافة إلى نظام دعوة للاعبين (واجهة جاهزة للتطوير المستقبلي).

---

## الملفات المُنشأة

### 1. `lib/features/group/presentation/screens/player_management_screen.dart`
**الوظيفة**: شاشة لإدارة اللاعبين
**الميزات**:
- إضافة لاعبين جدد
- تعديل أسماء اللاعبين
- حذف لاعبين (مع حماية المضيف)
- عرض قائمة اللاعبين الحالية
- إنشاء كود دعوة (4 أرقام)
- نسخ كود الدعوة

### 2. `lib/features/group/presentation/screens/join_game_screen.dart`
**الوظيفة**: شاشة للانضمام للعبة عبر كود الدعوة
**الميزات**:
- إدخال كود الدعوة (4 أرقام)
- زر لمسح QR Code (مستقبلي)
- واجهة بسيطة وواضحة

### 3. `docs/GROUP_MODE_GUIDE.md`
**الوظيفة**: دليل شامل للمستخدمين
**المحتوى**:
- كيفية إضافة وإدارة اللاعبين
- كيفية دعوة لاعبين
- كيفية الانضمام للعبة
- نصائح واستكشاف الأخطاء

---

## الملفات المُحدّثة

### 1. `lib/features/mode_selection/presentation/screens/mode_selection_screen.dart`
**التحديثات**:
- إضافة قسم "Players Management" في الوضع الجماعي
- عرض معاينة للاعبين الحاليين
- زر "Manage" لفتح شاشة إدارة اللاعبين
- دعم قائمة لاعبين مخصصة
- تمرير قائمة اللاعبين إلى GameScreen

### 2. `lib/features/home/presentation/screens/home_screen.dart`
**التحديثات**:
- إضافة زر "Join Game" في قائمة الأوضاع
- ربط مع شاشة JoinGameScreen

### 3. `lib/core/router/app_router.dart`
**التحديثات**:
- إضافة مسار `routeJoinGame`
- دعم `customPlayers` في GameScreen arguments

### 4. `lib/core/constants/app_constants.dart`
**التحديثات**:
- إضافة `routePlayerManagement`
- إضافة `routeJoinGame`

### 5. `lib/features/game/presentation/bloc/game_event.dart`
**التحديثات**:
- إضافة `customPlayers` إلى `GameStarted` event

### 6. `lib/features/game/presentation/screens/game_screen.dart`
**التحديثات**:
- إضافة `customPlayers` parameter
- تمرير `customPlayers` إلى GameStarted event

---

## البنية الجديدة

```
lib/features/group/
└── presentation/
    └── screens/
        ├── player_management_screen.dart  # إدارة اللاعبين
        └── join_game_screen.dart          # الانضمام للعبة
```

---

## كيفية الاستخدام

### للمضيف (Host)

1. **اختر Group Mode** من الشاشة الرئيسية
2. **في شاشة Mode Selection**:
   - استخدم "Quick Select" لاختيار عدد اللاعبين
   - أو اضغط "Manage" لإدارة اللاعبين بشكل متقدم
3. **في شاشة Player Management**:
   - أضف لاعبين: اضغط "+ Add Player"
   - عدّل الأسماء: اضغط على حقل الاسم واكتب الاسم الجديد
   - احذف لاعبين: اضغط أيقونة الحذف (لا يمكن حذف المضيف)
   - أنشئ كود دعوة: اضغط أيقونة "Invite Players" في شريط الأدوات
4. **أكد اللاعبين**: اضغط "Confirm Players"
5. **ابدأ اللعبة**: اضغط "Start Game"

### للاعبين المدعوين (Guests)

1. **اختر "Join Game"** من الشاشة الرئيسية
2. **أدخل كود الدعوة** (4 أرقام)
3. **اضغط "Join Game"**
4. **انتظر الاتصال** (في التطوير المستقبلي)

---

## الميزات المطبقة

### ✅ مكتملة

- [x] إضافة لاعبين
- [x] تعديل أسماء اللاعبين
- [x] حذف لاعبين (مع حماية المضيف)
- [x] عرض قائمة اللاعبين
- [x] إنشاء كود دعوة
- [x] واجهة الانضمام للعبة
- [x] تمرير قائمة اللاعبين إلى GameScreen
- [x] دعم في GameEvent و GameBloc

### 🔄 قيد التطوير

- [ ] تكامل مع خادم للدعوات الحقيقية
- [ ] QR Code Scanner
- [ ] Online Multiplayer
- [ ] Real-time Sync
- [ ] نظام الأصدقاء

---

## التفاصيل التقنية

### PlayerInfo Model

```dart
class PlayerInfo {
  final String id;
  String name;
  final bool isHost;
}
```

### Custom Players Format

```dart
List<Map<String, dynamic>> customPlayers = [
  {'id': 'player_0', 'name': 'Player 1', 'isHost': true},
  {'id': 'player_1', 'name': 'Player 2', 'isHost': false},
  // ...
]
```

### Integration with GameBloc

```dart
GameStarted(
  // ... other parameters
  customPlayers: [
    {'id': 'player_0', 'name': 'Player 1', 'isHost': true},
    // ...
  ],
)
```

---

## القيود الحالية

1. **Pass & Play فقط**: النظام الحالي يدعم Pass & Play (تمرير الجهاز)
2. **Invite Code تجريبي**: كود الدعوة يتم إنشاؤه محلياً، يحتاج خادم للعمل الكامل
3. **لا يوجد Online Multiplayer**: الميزة قيد التطوير

---

## الخطوات التالية للتطوير

### Phase 1: Backend Integration
1. إنشاء API للدعوات
2. إنشاء غرف اللعب
3. مزامنة الحالة بين اللاعبين

**📚 دليل التنفيذ الكامل**: راجع [`docs/CLOUDFLARE_MULTIPLAYER_GUIDE.md`](CLOUDFLARE_MULTIPLAYER_GUIDE.md) للتنفيذ على Cloudflare Workers + Durable Objects

**⚡ البدء السريع**: راجع [`docs/CLOUDFLARE_QUICK_START.md`](CLOUDFLARE_QUICK_START.md) للبدء في 5 دقائق

### Phase 2: Real-time Features
1. WebSocket للاتصال الفوري
2. مزامنة النقاط والخطوات
3. إشعارات للاعبين

### Phase 3: Advanced Features
1. QR Code Scanner
2. Deep Links
3. Social Sharing
4. Friend System

---

## الاختبار

### اختبارات يدوية مطلوبة:

1. **إضافة لاعبين**:
   - [ ] إضافة لاعب جديد
   - [ ] إضافة حتى 6 لاعبين
   - [ ] محاولة إضافة أكثر من 6 (يجب أن تفشل)

2. **تعديل الأسماء**:
   - [ ] تعديل اسم لاعب
   - [ ] حفظ التغييرات
   - [ ] التحقق من التحديث في المعاينة

3. **حذف لاعبين**:
   - [ ] حذف لاعب عادي
   - [ ] محاولة حذف المضيف (يجب أن تفشل)
   - [ ] محاولة حذف حتى يبقى لاعب واحد (يجب أن تفشل)

4. **كود الدعوة**:
   - [ ] إنشاء كود دعوة
   - [ ] نسخ الكود
   - [ ] التحقق من صحة الكود

5. **الانضمام للعبة**:
   - [ ] إدخال كود صحيح
   - [ ] إدخال كود خاطئ
   - [ ] التحقق من الرسائل

---

## ملاحظات

- جميع الملفات خالية من أخطاء اللنتر
- الكود يتبع Clean Architecture
- الواجهات متجاوبة وتدعم RTL
- التوثيق شامل ومفصل

---

## الدعم

للمزيد من المعلومات:
- راجع `docs/GROUP_MODE_GUIDE.md` للدليل الكامل
- راجع الكود المصدري للتفاصيل التقنية

